﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VideoPlayerApp.CustomControls
{
    public enum PlayerStatus
    {
        Playing,
        Paused
    }
}
